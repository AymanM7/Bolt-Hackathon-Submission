import React, { useState } from 'react';
import { MLPredictionInput, MLPredictionResult } from '../types';
import { mlPredictor } from '../utils/mlModel';
import { positions } from '../data/positions';
import { goals } from '../data/goals';
import { Brain, TrendingUp, AlertTriangle, CheckCircle, BarChart3 } from 'lucide-react';

interface MLPredictorProps {
  theme: 'light' | 'dark';
}

export function MLPredictor({ theme }: MLPredictorProps) {
  const [input, setInput] = useState<MLPredictionInput>({
    position: 'qb',
    goal: 'strength',
    exerciseCount: 5,
    totalSets: 20,
    averageIntensity: 80,
    muscleGroupDiversity: 4,
    equipmentVariety: 3,
    restBalance: 75
  });

  const [prediction, setPrediction] = useState<MLPredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handlePredict = async () => {
    setIsLoading(true);
    
    // Simulate API delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const result = mlPredictor.predict(input);
    setPrediction(result);
    setIsLoading(false);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return theme === 'dark' ? 'text-green-400' : 'text-green-600';
    if (score >= 80) return theme === 'dark' ? 'text-blue-400' : 'text-blue-600';
    if (score >= 70) return theme === 'dark' ? 'text-yellow-400' : 'text-yellow-600';
    return theme === 'dark' ? 'text-orange-400' : 'text-orange-600';
  };

  const getScoreGradient = (score: number) => {
    if (score >= 90) return 'from-green-500 to-emerald-600';
    if (score >= 80) return 'from-blue-500 to-indigo-600';
    if (score >= 70) return 'from-yellow-500 to-orange-600';
    return 'from-orange-500 to-red-600';
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className={`rounded-2xl border-2 p-6 ${
        theme === 'dark'
          ? 'border-gray-600 bg-gray-800/30'
          : 'border-white/50 bg-white/50'
      }`}>
        <div className="flex items-center space-x-4">
          <div className="p-3 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600">
            <Brain className="h-8 w-8 text-white" />
          </div>
          <div>
            <h2 className={`text-3xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              ML Workout Efficiency Predictor
            </h2>
            <p className={`text-lg mt-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
              Advanced ensemble model for predicting workout effectiveness
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Form */}
        <div className={`rounded-2xl border-2 p-6 ${
          theme === 'dark'
            ? 'border-gray-600 bg-gray-800/30'
            : 'border-white/50 bg-white/50'
        }`}>
          <h3 className={`text-xl font-bold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Workout Parameters
          </h3>
          
          <div className="space-y-6">
            {/* Position Selection */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                Position
              </label>
              <select
                value={input.position}
                onChange={(e) => setInput({ ...input, position: e.target.value })}
                className={`w-full p-3 rounded-lg border-2 transition-colors ${
                  theme === 'dark'
                    ? 'border-gray-600 bg-gray-700 text-white focus:border-purple-400'
                    : 'border-gray-200 bg-white text-gray-900 focus:border-purple-500'
                }`}
              >
                {positions.map(pos => (
                  <option key={pos.id} value={pos.id}>{pos.name}</option>
                ))}
              </select>
            </div>

            {/* Goal Selection */}
            <div>
              <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                Training Goal
              </label>
              <select
                value={input.goal}
                onChange={(e) => setInput({ ...input, goal: e.target.value })}
                className={`w-full p-3 rounded-lg border-2 transition-colors ${
                  theme === 'dark'
                    ? 'border-gray-600 bg-gray-700 text-white focus:border-purple-400'
                    : 'border-gray-200 bg-white text-gray-900 focus:border-purple-500'
                }`}
              >
                {goals.map(goal => (
                  <option key={goal.id} value={goal.id}>{goal.name}</option>
                ))}
              </select>
            </div>

            {/* Numeric Inputs */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  Exercise Count
                </label>
                <input
                  type="number"
                  min="3"
                  max="10"
                  value={input.exerciseCount}
                  onChange={(e) => setInput({ ...input, exerciseCount: parseInt(e.target.value) })}
                  className={`w-full p-3 rounded-lg border-2 transition-colors ${
                    theme === 'dark'
                      ? 'border-gray-600 bg-gray-700 text-white focus:border-purple-400'
                      : 'border-gray-200 bg-white text-gray-900 focus:border-purple-500'
                  }`}
                />
              </div>
              
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  Total Sets
                </label>
                <input
                  type="number"
                  min="10"
                  max="50"
                  value={input.totalSets}
                  onChange={(e) => setInput({ ...input, totalSets: parseInt(e.target.value) })}
                  className={`w-full p-3 rounded-lg border-2 transition-colors ${
                    theme === 'dark'
                      ? 'border-gray-600 bg-gray-700 text-white focus:border-purple-400'
                      : 'border-gray-200 bg-white text-gray-900 focus:border-purple-500'
                  }`}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  Average Intensity (%)
                </label>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={input.averageIntensity}
                  onChange={(e) => setInput({ ...input, averageIntensity: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-center mt-1">
                  <span className={`text-lg font-bold ${theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`}>
                    {input.averageIntensity}%
                  </span>
                </div>
              </div>
              
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  Muscle Group Diversity
                </label>
                <input
                  type="range"
                  min="1"
                  max="6"
                  value={input.muscleGroupDiversity}
                  onChange={(e) => setInput({ ...input, muscleGroupDiversity: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-center mt-1">
                  <span className={`text-lg font-bold ${theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`}>
                    {input.muscleGroupDiversity}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  Equipment Variety
                </label>
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={input.equipmentVariety}
                  onChange={(e) => setInput({ ...input, equipmentVariety: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-center mt-1">
                  <span className={`text-lg font-bold ${theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`}>
                    {input.equipmentVariety}
                  </span>
                </div>
              </div>
              
              <div>
                <label className={`block text-sm font-medium mb-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                  Rest Balance (%)
                </label>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={input.restBalance}
                  onChange={(e) => setInput({ ...input, restBalance: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-center mt-1">
                  <span className={`text-lg font-bold ${theme === 'dark' ? 'text-purple-400' : 'text-purple-600'}`}>
                    {input.restBalance}%
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={handlePredict}
              disabled={isLoading}
              className="w-full py-4 px-6 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all duration-200 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
                  <span>Analyzing...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>Predict Efficiency</span>
                </div>
              )}
            </button>
          </div>
        </div>

        {/* Prediction Results */}
        <div className={`rounded-2xl border-2 p-6 ${
          theme === 'dark'
            ? 'border-gray-600 bg-gray-800/30'
            : 'border-white/50 bg-white/50'
        }`}>
          <h3 className={`text-xl font-bold mb-6 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            Prediction Results
          </h3>

          {!prediction ? (
            <div className="text-center py-12">
              <Brain className={`h-16 w-16 mx-auto mb-4 ${theme === 'dark' ? 'text-gray-600' : 'text-gray-400'}`} />
              <p className={`text-lg ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                Configure your workout parameters and click "Predict Efficiency" to see AI-powered insights
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Efficiency Score */}
              <div className={`rounded-xl border-2 p-6 ${
                theme === 'dark'
                  ? 'border-gray-600 bg-gray-700/30'
                  : 'border-gray-200 bg-gray-50'
              }`}>
                <div className="flex items-center justify-between mb-4">
                  <h4 className={`text-lg font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    Predicted Efficiency
                  </h4>
                  <div className="flex items-center space-x-2">
                    <TrendingUp className={`h-5 w-5 ${getScoreColor(prediction.predictedEfficiency)}`} />
                    <span className={`text-3xl font-bold ${getScoreColor(prediction.predictedEfficiency)}`}>
                      {prediction.predictedEfficiency}
                    </span>
                    <span className={`text-lg ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                      /100
                    </span>
                  </div>
                </div>
                
                <div className={`w-full h-3 rounded-full mb-4 ${theme === 'dark' ? 'bg-gray-600' : 'bg-gray-200'}`}>
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${getScoreGradient(prediction.predictedEfficiency)} transition-all duration-1000 ease-out`}
                    style={{ width: `${prediction.predictedEfficiency}%` }}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <span className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                    Confidence: {Math.round(prediction.confidence * 100)}%
                  </span>
                  <span className={`text-sm font-medium ${
                    prediction.predictedEfficiency >= 85 
                      ? 'text-green-600' 
                      : prediction.predictedEfficiency >= 70 
                        ? 'text-yellow-600' 
                        : 'text-orange-600'
                  }`}>
                    {prediction.predictedEfficiency >= 85 ? 'Elite' : 
                     prediction.predictedEfficiency >= 70 ? 'Good' : 'Needs Improvement'}
                  </span>
                </div>
              </div>

              {/* Recommendations */}
              {prediction.recommendations.length > 0 && (
                <div className={`rounded-xl border-2 p-6 ${
                  theme === 'dark'
                    ? 'border-gray-600 bg-gray-700/30'
                    : 'border-gray-200 bg-gray-50'
                }`}>
                  <h4 className={`text-lg font-bold mb-4 flex items-center space-x-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span>Recommendations</span>
                  </h4>
                  <ul className="space-y-2">
                    {prediction.recommendations.map((rec, index) => (
                      <li key={index} className={`flex items-start space-x-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                        <span className="text-green-500 mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Risk Factors */}
              {prediction.riskFactors.length > 0 && (
                <div className={`rounded-xl border-2 p-6 ${
                  theme === 'dark'
                    ? 'border-red-600/50 bg-red-900/20'
                    : 'border-red-200 bg-red-50'
                }`}>
                  <h4 className={`text-lg font-bold mb-4 flex items-center space-x-2 ${theme === 'dark' ? 'text-red-400' : 'text-red-700'}`}>
                    <AlertTriangle className="h-5 w-5" />
                    <span>Risk Factors</span>
                  </h4>
                  <ul className="space-y-2">
                    {prediction.riskFactors.map((risk, index) => (
                      <li key={index} className={`flex items-start space-x-2 ${theme === 'dark' ? 'text-red-300' : 'text-red-700'}`}>
                        <span className="text-red-500 mt-1">⚠</span>
                        <span>{risk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}