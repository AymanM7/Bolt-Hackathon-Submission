import React from 'react';
import { Goal } from '../types';
import { goals } from '../data/goals';
import { Zap, Dumbbell, Navigation, Battery, Heart, Waves } from 'lucide-react';

interface GoalSelectorProps {
  selectedGoal: Goal | null;
  onSelect: (goal: Goal) => void;
  theme: 'light' | 'dark';
}

const goalIcons = {
  speed: Zap,
  strength: Dumbbell,
  agility: Navigation,
  endurance: Heart,
  power: Battery,
  flexibility: Waves
};

export function GoalSelector({ selectedGoal, onSelect, theme }: GoalSelectorProps) {
  return (
    <div className="space-y-6">
      <h2 className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
        Choose Your Training Goal
      </h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {goals.map((goal) => {
          const IconComponent = goalIcons[goal.category as keyof typeof goalIcons] || Dumbbell;
          
          return (
            <button
              key={goal.id}
              onClick={() => onSelect(goal)}
              className={`relative p-6 rounded-xl border-2 transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 text-left group ${
                selectedGoal?.id === goal.id
                  ? theme === 'dark'
                    ? 'border-purple-400 bg-purple-500/20 shadow-lg shadow-purple-500/25'
                    : 'border-purple-500 bg-purple-50 shadow-lg shadow-purple-500/25'
                  : theme === 'dark'
                    ? 'border-gray-600 bg-gray-800/50 hover:border-purple-400 hover:bg-purple-500/10'
                    : 'border-gray-200 bg-white hover:border-purple-300 hover:bg-purple-50'
              }`}
            >
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-lg ${
                  selectedGoal?.id === goal.id
                    ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white'
                    : theme === 'dark'
                      ? 'bg-gray-700 text-purple-400'
                      : 'bg-gray-100 text-purple-600'
                }`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <div className="flex-1">
                  <h3 className={`font-semibold text-lg mb-2 ${
                    selectedGoal?.id === goal.id
                      ? theme === 'dark' ? 'text-white' : 'text-purple-900'
                      : theme === 'dark' ? 'text-gray-200' : 'text-gray-800'
                  }`}>
                    {goal.name}
                  </h3>
                  <p className={`text-sm ${
                    selectedGoal?.id === goal.id
                      ? theme === 'dark' ? 'text-purple-200' : 'text-purple-700'
                      : theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                  }`}>
                    {goal.description}
                  </p>
                </div>
              </div>
              {selectedGoal?.id === goal.id && (
                <div className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-gradient-to-r from-purple-500 to-indigo-600 border-2 border-white shadow-lg" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}