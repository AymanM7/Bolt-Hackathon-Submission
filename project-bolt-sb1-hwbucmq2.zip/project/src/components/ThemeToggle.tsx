import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { Theme } from '../hooks/useTheme';

interface ThemeToggleProps {
  theme: Theme;
  onToggle: () => void;
}

export function ThemeToggle({ theme, onToggle }: ThemeToggleProps) {
  return (
    <button
      onClick={onToggle}
      className="relative inline-flex h-10 w-20 items-center justify-center rounded-full bg-white/10 backdrop-blur-sm border border-white/20 transition-all duration-300 hover:bg-white/20 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-transparent"
      aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
    >
      <div className={`absolute inset-0.5 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 transition-all duration-300 ${theme === 'dark' ? 'translate-x-0' : 'translate-x-10'}`} style={{ width: '2rem' }} />
      <div className="relative flex w-full items-center justify-between px-2">
        <Moon className={`h-4 w-4 transition-colors duration-300 ${theme === 'dark' ? 'text-white' : 'text-gray-400'}`} />
        <Sun className={`h-4 w-4 transition-colors duration-300 ${theme === 'light' ? 'text-white' : 'text-gray-400'}`} />
      </div>
    </button>
  );
}