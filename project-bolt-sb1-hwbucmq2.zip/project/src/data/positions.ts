import { Position } from '../types';

export const positions: Position[] = [
  // Offense
  { 
    id: 'qb', 
    name: 'Quarterback', 
    category: 'offense', 
    icon: '🎯',
    primaryAttributes: ['Arm Strength', 'Accuracy', 'Decision Making', 'Pocket Presence'],
    secondaryAttributes: ['Mobility', 'Leadership', 'Vision'],
    injuryRisk: 'high',
    physicalDemands: { strength: 70, speed: 60, agility: 75, endurance: 80, power: 65 }
  },
  { 
    id: 'rb', 
    name: 'Running Back', 
    category: 'offense', 
    icon: '🏃',
    primaryAttributes: ['Speed', 'Vision', 'Balance', 'Power'],
    secondaryAttributes: ['Hands', 'Pass Protection', 'Cutting Ability'],
    injuryRisk: 'high',
    physicalDemands: { strength: 85, speed: 95, agility: 90, endurance: 85, power: 90 }
  },
  { 
    id: 'wr', 
    name: 'Wide Receiver', 
    category: 'offense', 
    icon: '🙌',
    primaryAttributes: ['Speed', 'Route Running', 'Hands', 'Separation'],
    secondaryAttributes: ['Jump Ball Ability', 'YAC', 'Blocking'],
    injuryRisk: 'medium',
    physicalDemands: { strength: 70, speed: 95, agility: 85, endurance: 75, power: 80 }
  },
  { 
    id: 'te', 
    name: 'Tight End', 
    category: 'offense', 
    icon: '💪',
    primaryAttributes: ['Blocking', 'Hands', 'Size', 'Versatility'],
    secondaryAttributes: ['Speed', 'Route Running', 'Red Zone Threat'],
    injuryRisk: 'medium',
    physicalDemands: { strength: 90, speed: 70, agility: 65, endurance: 80, power: 85 }
  },
  { 
    id: 'ol', 
    name: 'Offensive Line', 
    category: 'offense', 
    icon: '🛡️',
    primaryAttributes: ['Strength', 'Technique', 'Footwork', 'Communication'],
    secondaryAttributes: ['Flexibility', 'Hand Placement', 'Anchor'],
    injuryRisk: 'medium',
    physicalDemands: { strength: 95, speed: 40, agility: 60, endurance: 85, power: 90 }
  },
  
  // Defense
  { 
    id: 'dl', 
    name: 'Defensive Line', 
    category: 'defense', 
    icon: '🔥',
    primaryAttributes: ['Strength', 'Pass Rush', 'Run Stopping', 'Hand Usage'],
    secondaryAttributes: ['Flexibility', 'Stamina', 'Gap Control'],
    injuryRisk: 'medium',
    physicalDemands: { strength: 95, speed: 70, agility: 65, endurance: 80, power: 95 }
  },
  { 
    id: 'lb', 
    name: 'Linebacker', 
    category: 'defense', 
    icon: '⚡',
    primaryAttributes: ['Tackling', 'Coverage', 'Run Support', 'Blitzing'],
    secondaryAttributes: ['Leadership', 'Instincts', 'Versatility'],
    injuryRisk: 'high',
    physicalDemands: { strength: 85, speed: 80, agility: 85, endurance: 90, power: 85 }
  },
  { 
    id: 'cb', 
    name: 'Cornerback', 
    category: 'defense', 
    icon: '🦅',
    primaryAttributes: ['Speed', 'Coverage', 'Ball Skills', 'Backpedal'],
    secondaryAttributes: ['Press Coverage', 'Tackling', 'Route Recognition'],
    injuryRisk: 'medium',
    physicalDemands: { strength: 65, speed: 95, agility: 95, endurance: 85, power: 75 }
  },
  { 
    id: 's', 
    name: 'Safety', 
    category: 'defense', 
    icon: '🎯',
    primaryAttributes: ['Range', 'Tackling', 'Ball Skills', 'Communication'],
    secondaryAttributes: ['Run Support', 'Coverage Versatility', 'Blitzing'],
    injuryRisk: 'medium',
    physicalDemands: { strength: 75, speed: 85, agility: 80, endurance: 85, power: 80 }
  },
  
  // Special Teams
  { 
    id: 'k', 
    name: 'Kicker', 
    category: 'special', 
    icon: '⚽',
    primaryAttributes: ['Leg Strength', 'Accuracy', 'Mental Toughness', 'Consistency'],
    secondaryAttributes: ['Flexibility', 'Core Strength', 'Pressure Performance'],
    injuryRisk: 'low',
    physicalDemands: { strength: 60, speed: 30, agility: 40, endurance: 50, power: 70 }
  },
  { 
    id: 'p', 
    name: 'Punter', 
    category: 'special', 
    icon: '🦵',
    primaryAttributes: ['Leg Strength', 'Hang Time', 'Directional Punting', 'Consistency'],
    secondaryAttributes: ['Fake Punt Ability', 'Holding', 'Coverage'],
    injuryRisk: 'low',
    physicalDemands: { strength: 65, speed: 40, agility: 45, endurance: 55, power: 75 }
  },
];