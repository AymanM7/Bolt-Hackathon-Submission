import { Goal } from '../types';

export const goals: Goal[] = [
  {
    id: 'speed',
    name: 'Increase Speed',
    description: 'Improve 40-yard dash time, acceleration, and top-end speed',
    category: 'speed',
    targetMetrics: ['40-yard dash', '10-yard split', 'Flying 20s', 'Top speed MPH']
  },
  {
    id: 'strength',
    name: 'Build Strength',
    description: 'Increase max bench press, squat, deadlift, and functional strength',
    category: 'strength',
    targetMetrics: ['1RM Bench', '1RM Squat', '1RM Deadlift', 'Power Clean']
  },
  {
    id: 'agility',
    name: 'Enhance Agility',
    description: 'Improve change of direction, footwork, and reactive ability',
    category: 'agility',
    targetMetrics: ['3-Cone Drill', '5-10-5 Shuttle', 'L-Drill', 'Reactive Agility']
  },
  {
    id: 'power',
    name: 'Explosive Power',
    description: 'Develop vertical jump, broad jump, and explosive movements',
    category: 'power',
    targetMetrics: ['Vertical Jump', 'Broad Jump', 'Power Clean', 'Medicine Ball Throw']
  },
  {
    id: 'endurance',
    name: 'Cardiovascular Endurance',
    description: 'Improve stamina, game-long performance, and recovery',
    category: 'endurance',
    targetMetrics: ['VO2 Max', '300-yard Shuttle', 'Lactate Threshold', 'Recovery Rate']
  },
  {
    id: 'flexibility',
    name: 'Flexibility & Mobility',
    description: 'Prevent injuries, improve range of motion, and movement quality',
    category: 'flexibility',
    targetMetrics: ['Hip Mobility', 'Shoulder ROM', 'Ankle Flexibility', 'Movement Screen']
  }
];