import { useState, useEffect } from 'react';
import { WorkoutHistory } from '../types';

export function useWorkoutHistory() {
  const [history, setHistory] = useState<WorkoutHistory[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('workoutHistory');
      return saved ? JSON.parse(saved) : [];
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem('workoutHistory', JSON.stringify(history));
  }, [history]);

  const addToHistory = (entry: Omit<WorkoutHistory, 'id' | 'createdAt'>) => {
    const newEntry: WorkoutHistory = {
      id: Date.now().toString(),
      createdAt: new Date(),
      ...entry
    };
    setHistory(prev => [newEntry, ...prev.slice(0, 9)]); // Keep last 10
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return { history, addToHistory, clearHistory };
}