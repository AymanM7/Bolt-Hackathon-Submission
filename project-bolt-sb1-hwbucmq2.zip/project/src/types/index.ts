export interface Position {
  id: string;
  name: string;
  category: 'offense' | 'defense' | 'special';
  icon: string;
  primaryAttributes: string[];
  secondaryAttributes: string[];
  injuryRisk: 'low' | 'medium' | 'high';
  physicalDemands: {
    strength: number;
    speed: number;
    agility: number;
    endurance: number;
    power: number;
  };
}

export interface Goal {
  id: string;
  name: string;
  description: string;
  category: 'strength' | 'speed' | 'agility' | 'endurance' | 'power' | 'flexibility';
  targetMetrics: string[];
}

export interface Exercise {
  name: string;
  sets: string;
  reps: string;
  rest: string;
  intensity: number;
  muscleGroups: string[];
  equipment: string[];
}

export interface Workout {
  position: string;
  goal: string;
  exercises: Exercise[];
  efficiency: {
    score: number;
    comment: string;
    breakdown: {
      positionRelevance: number;
      intensityBalance: number;
      exerciseVariety: number;
      injuryPrevention: number;
    };
  };
  estimatedDuration: number;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Elite';
}

export interface WorkoutHistory {
  id: string;
  position: string;
  goal: string;
  workout: Workout;
  createdAt: Date;
  completed?: boolean;
  userRating?: number;
}

export interface PlayerStats {
  id: string;
  name: string;
  position: string;
  workoutsCompleted: number;
  averageEfficiency: number;
  totalTrainingHours: number;
  strengthGains: number;
  speedImprovement: number;
  injuryRate: number;
  lastWorkout: Date;
  weeklyProgress: {
    week: string;
    efficiency: number;
    workouts: number;
    duration: number;
  }[];
}

export interface MLPredictionInput {
  position: string;
  goal: string;
  exerciseCount: number;
  totalSets: number;
  averageIntensity: number;
  muscleGroupDiversity: number;
  equipmentVariety: number;
  restBalance: number;
}

export interface MLPredictionResult {
  predictedEfficiency: number;
  confidence: number;
  recommendations: string[];
  riskFactors: string[];
}