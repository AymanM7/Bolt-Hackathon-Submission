import { MLPredictionInput, MLPredictionResult } from '../types';

// Simple ensemble model using multiple regression approaches
export class WorkoutEfficiencyPredictor {
  private weights: { [key: string]: number } = {
    positionWeight: 0.25,
    goalWeight: 0.20,
    exerciseCountWeight: 0.15,
    intensityWeight: 0.20,
    varietyWeight: 0.10,
    balanceWeight: 0.10
  };

  private positionScores: { [key: string]: number } = {
    'qb': 75, 'rb': 85, 'wr': 80, 'te': 82, 'ol': 88,
    'dl': 90, 'lb': 85, 'cb': 78, 's': 80, 'k': 65, 'p': 68
  };

  private goalScores: { [key: string]: number } = {
    'speed': 85, 'strength': 90, 'agility': 82, 
    'power': 88, 'endurance': 75, 'flexibility': 70
  };

  predict(input: MLPredictionInput): MLPredictionResult {
    // Ensemble of three models
    const linearScore = this.linearRegression(input);
    const treeScore = this.decisionTree(input);
    const neuralScore = this.simpleNeural(input);
    
    // Weighted ensemble
    const predictedEfficiency = Math.round(
      linearScore * 0.4 + treeScore * 0.35 + neuralScore * 0.25
    );
    
    // Calculate confidence based on model agreement
    const scores = [linearScore, treeScore, neuralScore];
    const variance = this.calculateVariance(scores);
    const confidence = Math.max(0.6, 1 - (variance / 100));
    
    const recommendations = this.generateRecommendations(input, predictedEfficiency);
    const riskFactors = this.identifyRiskFactors(input);
    
    return {
      predictedEfficiency: Math.min(Math.max(predictedEfficiency, 40), 100),
      confidence: Math.round(confidence * 100) / 100,
      recommendations,
      riskFactors
    };
  }

  private linearRegression(input: MLPredictionInput): number {
    const positionScore = this.positionScores[input.position] || 75;
    const goalScore = this.goalScores[input.goal] || 80;
    
    let score = 
      positionScore * this.weights.positionWeight +
      goalScore * this.weights.goalWeight +
      this.normalizeExerciseCount(input.exerciseCount) * this.weights.exerciseCountWeight +
      input.averageIntensity * this.weights.intensityWeight +
      this.normalizeVariety(input.muscleGroupDiversity) * this.weights.varietyWeight +
      this.normalizeBalance(input.restBalance) * this.weights.balanceWeight;
    
    return Math.min(Math.max(score, 40), 100);
  }

  private decisionTree(input: MLPredictionInput): number {
    let score = 75; // Base score
    
    // Position-based rules
    if (['rb', 'dl', 'ol'].includes(input.position)) {
      score += 5; // High-intensity positions
    }
    if (['k', 'p'].includes(input.position)) {
      score -= 10; // Specialized positions
    }
    
    // Goal-based rules
    if (input.goal === 'strength' && input.averageIntensity > 80) {
      score += 10;
    }
    if (input.goal === 'speed' && input.exerciseCount < 5) {
      score -= 5;
    }
    
    // Exercise composition rules
    if (input.exerciseCount >= 5 && input.exerciseCount <= 6) {
      score += 8;
    } else if (input.exerciseCount > 6) {
      score -= 3; // Too many exercises
    }
    
    if (input.muscleGroupDiversity >= 4) {
      score += 5;
    }
    
    if (input.averageIntensity >= 75 && input.averageIntensity <= 85) {
      score += 8;
    }
    
    return Math.min(Math.max(score, 40), 100);
  }

  private simpleNeural(input: MLPredictionInput): number {
    // Simplified neural network simulation
    const inputs = [
      this.positionScores[input.position] / 100 || 0.75,
      this.goalScores[input.goal] / 100 || 0.8,
      input.exerciseCount / 8,
      input.averageIntensity / 100,
      input.muscleGroupDiversity / 6,
      input.restBalance / 100
    ];
    
    // Hidden layer (simplified)
    const hidden = inputs.map(x => this.sigmoid(x * 2 - 1));
    
    // Output layer
    const output = hidden.reduce((sum, h, i) => sum + h * (0.8 + i * 0.05), 0);
    
    return Math.min(Math.max(output * 100, 40), 100);
  }

  private sigmoid(x: number): number {
    return 1 / (1 + Math.exp(-x));
  }

  private calculateVariance(scores: number[]): number {
    const mean = scores.reduce((a, b) => a + b) / scores.length;
    const variance = scores.reduce((sum, score) => sum + Math.pow(score - mean, 2), 0) / scores.length;
    return variance;
  }

  private normalizeExerciseCount(count: number): number {
    // Optimal range is 5-6 exercises
    if (count >= 5 && count <= 6) return 90;
    if (count === 4 || count === 7) return 75;
    if (count === 3 || count === 8) return 60;
    return 45;
  }

  private normalizeVariety(diversity: number): number {
    return Math.min(diversity * 15, 100);
  }

  private normalizeBalance(balance: number): number {
    return Math.min(Math.max(balance, 60), 100);
  }

  private generateRecommendations(input: MLPredictionInput, score: number): string[] {
    const recommendations: string[] = [];
    
    if (score < 70) {
      recommendations.push("Consider increasing exercise intensity for better results");
    }
    
    if (input.exerciseCount < 5) {
      recommendations.push("Add 1-2 more exercises for comprehensive training");
    }
    
    if (input.exerciseCount > 6) {
      recommendations.push("Reduce exercise count to prevent overtraining");
    }
    
    if (input.muscleGroupDiversity < 3) {
      recommendations.push("Include more diverse muscle groups for balanced development");
    }
    
    if (input.averageIntensity < 70) {
      recommendations.push("Increase workout intensity for NFL-level conditioning");
    }
    
    if (input.averageIntensity > 90) {
      recommendations.push("Consider moderating intensity to prevent injury");
    }
    
    if (input.restBalance < 70) {
      recommendations.push("Optimize rest periods for better recovery and performance");
    }
    
    // Position-specific recommendations
    if (['rb', 'wr', 'cb'].includes(input.position) && input.goal !== 'speed') {
      recommendations.push("Consider adding speed-focused exercises for your position");
    }
    
    if (['ol', 'dl'].includes(input.position) && input.goal !== 'strength') {
      recommendations.push("Incorporate more strength training for your position demands");
    }
    
    return recommendations.slice(0, 3); // Limit to top 3 recommendations
  }

  private identifyRiskFactors(input: MLPredictionInput): string[] {
    const risks: string[] = [];
    
    if (input.averageIntensity > 90) {
      risks.push("High injury risk due to excessive intensity");
    }
    
    if (input.exerciseCount > 7) {
      risks.push("Overtraining risk with too many exercises");
    }
    
    if (input.muscleGroupDiversity < 2) {
      risks.push("Muscle imbalance risk from limited variety");
    }
    
    if (input.restBalance < 60) {
      risks.push("Inadequate recovery time between exercises");
    }
    
    // Position-specific risks
    if (['rb', 'lb'].includes(input.position) && input.averageIntensity > 85) {
      risks.push("High-contact position with intense training increases injury risk");
    }
    
    return risks.slice(0, 2); // Limit to top 2 risk factors
  }
}

export const mlPredictor = new WorkoutEfficiencyPredictor();