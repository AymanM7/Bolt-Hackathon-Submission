import { Exercise, Workout, Position, Goal } from '../types';
import { positions } from '../data/positions';
import { goals } from '../data/goals';

interface PositionWorkouts {
  [key: string]: {
    [goal: string]: Exercise[];
  };
}

const nflWorkoutDatabase: PositionWorkouts = {
  qb: {
    speed: [
      { name: 'Drop-back Speed Drills', sets: '8', reps: '5-step drops', rest: '45s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Pocket Movement Sprints', sets: '6', reps: '10 yards', rest: '60s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['ladder'] },
      { name: 'Scramble Simulation', sets: '5', reps: '15 yards', rest: '90s', intensity: 90, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Lateral Shuffle to Sprint', sets: '6', reps: '5+15 yards', rest: '75s', intensity: 85, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Resisted Sprint Releases', sets: '4', reps: '20 yards', rest: '2 min', intensity: 95, muscleGroups: ['legs', 'core'], equipment: ['resistance bands'] }
    ],
    strength: [
      { name: 'Single-Arm Dumbbell Press', sets: '4', reps: '8-10 each', rest: '90s', intensity: 80, muscleGroups: ['chest', 'shoulders', 'core'], equipment: ['dumbbells'] },
      { name: 'Rotational Medicine Ball Throws', sets: '4', reps: '12 each side', rest: '60s', intensity: 85, muscleGroups: ['core', 'shoulders'], equipment: ['medicine ball'] },
      { name: 'Bulgarian Split Squats', sets: '3', reps: '12 each leg', rest: '90s', intensity: 75, muscleGroups: ['legs', 'glutes'], equipment: ['bench'] },
      { name: 'Cable Wood Chops', sets: '3', reps: '15 each side', rest: '45s', intensity: 70, muscleGroups: ['core', 'shoulders'], equipment: ['cable machine'] },
      { name: 'Single-Leg RDL', sets: '3', reps: '10 each leg', rest: '60s', intensity: 75, muscleGroups: ['hamstrings', 'glutes', 'core'], equipment: ['dumbbells'] },
      { name: 'Farmer\'s Walk', sets: '3', reps: '40 yards', rest: '2 min', intensity: 80, muscleGroups: ['grip', 'core', 'traps'], equipment: ['dumbbells'] }
    ],
    agility: [
      { name: 'Pocket Presence Drill', sets: '8', reps: '10 seconds', rest: '45s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: '5-Step Drop + Rollout', sets: '6', reps: '1 each direction', rest: '60s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Cone Weave + Throw', sets: '5', reps: '1', rest: '90s', intensity: 85, muscleGroups: ['legs', 'core', 'shoulders'], equipment: ['cones', 'football'] },
      { name: 'Lateral Bounds', sets: '4', reps: '8 each direction', rest: '60s', intensity: 75, muscleGroups: ['legs', 'glutes'], equipment: ['none'] },
      { name: 'Quick Feet Ladder', sets: '5', reps: '2 lengths', rest: '45s', intensity: 70, muscleGroups: ['legs', 'calves'], equipment: ['agility ladder'] }
    ]
  },
  rb: {
    speed: [
      { name: 'Flying 20s', sets: '6', reps: '1', rest: '3 min', intensity: 95, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Hill Sprints', sets: '8', reps: '30 yards', rest: '2 min', intensity: 90, muscleGroups: ['legs', 'glutes', 'calves'], equipment: ['hill'] },
      { name: 'Parachute Runs', sets: '5', reps: '40 yards', rest: '2.5 min', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['parachute'] },
      { name: 'Burst Through Drill', sets: '10', reps: '5 yards', rest: '60s', intensity: 95, muscleGroups: ['legs', 'core'], equipment: ['bags'] },
      { name: 'Stutter Step to Sprint', sets: '6', reps: '1', rest: '90s', intensity: 85, muscleGroups: ['legs', 'calves'], equipment: ['cones'] }
    ],
    strength: [
      { name: 'Hex Bar Deadlift', sets: '5', reps: '5', rest: '3 min', intensity: 90, muscleGroups: ['legs', 'back', 'glutes'], equipment: ['hex bar'] },
      { name: 'Bulgarian Split Squats', sets: '4', reps: '12 each leg', rest: '90s', intensity: 80, muscleGroups: ['legs', 'glutes'], equipment: ['bench', 'dumbbells'] },
      { name: 'Incline Dumbbell Press', sets: '4', reps: '8-10', rest: '2 min', intensity: 75, muscleGroups: ['chest', 'shoulders'], equipment: ['dumbbells', 'bench'] },
      { name: 'Single-Leg RDL', sets: '3', reps: '10 each leg', rest: '60s', intensity: 75, muscleGroups: ['hamstrings', 'glutes'], equipment: ['dumbbells'] },
      { name: 'Weighted Step-Ups', sets: '4', reps: '12 each leg', rest: '90s', intensity: 80, muscleGroups: ['legs', 'glutes'], equipment: ['box', 'dumbbells'] },
      { name: 'Bear Crawl', sets: '3', reps: '20 yards', rest: '90s', intensity: 70, muscleGroups: ['core', 'shoulders'], equipment: ['none'] }
    ],
    agility: [
      { name: 'Cut and Go Drill', sets: '8', reps: '1', rest: '60s', intensity: 90, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Box Drill (4-corner)', sets: '5', reps: '2', rest: '90s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Jump Cut Drill', sets: '8', reps: '5 cuts', rest: '45s', intensity: 85, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Cone Slalom', sets: '6', reps: '1', rest: '90s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Reactive Cutting', sets: '6', reps: '5 reactions', rest: '75s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones', 'partner'] }
    ]
  },
  wr: {
    speed: [
      { name: 'Route-Specific Sprints', sets: '8', reps: '1', rest: '90s', intensity: 90, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Release + Acceleration', sets: '6', reps: '15 yards', rest: '75s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Comeback Route Sprints', sets: '5', reps: '1', rest: '2 min', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Flying 10s', sets: '6', reps: '1', rest: '2.5 min', intensity: 95, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Resisted Releases', sets: '4', reps: '10 yards', rest: '90s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['resistance bands'] }
    ],
    strength: [
      { name: 'Single-Leg Squats', sets: '4', reps: '8 each leg', rest: '90s', intensity: 80, muscleGroups: ['legs', 'glutes', 'core'], equipment: ['none'] },
      { name: 'Dumbbell Bench Press', sets: '4', reps: '10-12', rest: '2 min', intensity: 75, muscleGroups: ['chest', 'shoulders'], equipment: ['dumbbells'] },
      { name: 'Single-Arm Row', sets: '3', reps: '12 each arm', rest: '60s', intensity: 70, muscleGroups: ['back', 'core'], equipment: ['dumbbells'] },
      { name: 'Lateral Lunges', sets: '3', reps: '12 each leg', rest: '60s', intensity: 70, muscleGroups: ['legs', 'glutes'], equipment: ['dumbbells'] },
      { name: 'Plank to Push-Up', sets: '3', reps: '10', rest: '45s', intensity: 65, muscleGroups: ['core', 'chest'], equipment: ['none'] }
    ],
    agility: [
      { name: 'Route Running Drill', sets: '8', reps: '1 route', rest: '60s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Mirror Drill', sets: '6', reps: '15 seconds', rest: '45s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['partner'] },
      { name: 'W-Drill', sets: '5', reps: '1', rest: '90s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Stem + Break', sets: '8', reps: '1 each direction', rest: '60s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Quick Feet Box', sets: '4', reps: '20 seconds', rest: '60s', intensity: 75, muscleGroups: ['legs', 'calves'], equipment: ['box'] }
    ]
  },
  ol: {
    strength: [
      { name: 'Barbell Back Squat', sets: '5', reps: '5', rest: '3 min', intensity: 90, muscleGroups: ['legs', 'glutes', 'core'], equipment: ['barbell'] },
      { name: 'Bench Press', sets: '5', reps: '6-8', rest: '3 min', intensity: 85, muscleGroups: ['chest', 'shoulders', 'triceps'], equipment: ['barbell'] },
      { name: 'Deadlift', sets: '4', reps: '5', rest: '3 min', intensity: 90, muscleGroups: ['back', 'legs', 'glutes'], equipment: ['barbell'] },
      { name: 'Overhead Press', sets: '4', reps: '8-10', rest: '2.5 min', intensity: 80, muscleGroups: ['shoulders', 'core'], equipment: ['barbell'] },
      { name: 'Bent-Over Row', sets: '4', reps: '8-10', rest: '2 min', intensity: 75, muscleGroups: ['back', 'biceps'], equipment: ['barbell'] },
      { name: 'Farmer\'s Walk', sets: '3', reps: '50 yards', rest: '2 min', intensity: 85, muscleGroups: ['grip', 'core', 'traps'], equipment: ['dumbbells'] }
    ],
    agility: [
      { name: 'Kick Slide Drill', sets: '6', reps: '10 yards each', rest: '60s', intensity: 75, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Pass Set Footwork', sets: '8', reps: '5 sets', rest: '45s', intensity: 70, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Mirror Drill', sets: '5', reps: '15 seconds', rest: '60s', intensity: 75, muscleGroups: ['legs', 'core'], equipment: ['partner'] },
      { name: 'Lateral Shuffle', sets: '4', reps: '20 yards', rest: '60s', intensity: 70, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Quick Feet Ladder', sets: '4', reps: '2 lengths', rest: '45s', intensity: 65, muscleGroups: ['legs', 'calves'], equipment: ['ladder'] }
    ]
  },
  dl: {
    strength: [
      { name: 'Deadlift', sets: '5', reps: '5', rest: '3 min', intensity: 95, muscleGroups: ['back', 'legs', 'glutes'], equipment: ['barbell'] },
      { name: 'Bench Press', sets: '5', reps: '6-8', rest: '3 min', intensity: 85, muscleGroups: ['chest', 'shoulders'], equipment: ['barbell'] },
      { name: 'Power Clean', sets: '4', reps: '5', rest: '2.5 min', intensity: 90, muscleGroups: ['legs', 'back', 'shoulders'], equipment: ['barbell'] },
      { name: 'Weighted Pull-ups', sets: '4', reps: '8-10', rest: '2 min', intensity: 80, muscleGroups: ['back', 'biceps'], equipment: ['pull-up bar', 'weight belt'] },
      { name: 'Box Squats', sets: '4', reps: '8', rest: '2.5 min', intensity: 85, muscleGroups: ['legs', 'glutes'], equipment: ['barbell', 'box'] },
      { name: 'Sled Push', sets: '4', reps: '20 yards', rest: '2 min', intensity: 90, muscleGroups: ['legs', 'core'], equipment: ['sled'] }
    ],
    power: [
      { name: 'Medicine Ball Slams', sets: '5', reps: '8', rest: '90s', intensity: 90, muscleGroups: ['core', 'shoulders'], equipment: ['medicine ball'] },
      { name: 'Box Jumps', sets: '4', reps: '6', rest: '2 min', intensity: 85, muscleGroups: ['legs', 'glutes'], equipment: ['box'] },
      { name: 'Battle Ropes', sets: '4', reps: '30 seconds', rest: '90s', intensity: 85, muscleGroups: ['arms', 'core'], equipment: ['battle ropes'] },
      { name: 'Tire Flips', sets: '3', reps: '8', rest: '2.5 min', intensity: 95, muscleGroups: ['legs', 'back', 'core'], equipment: ['tire'] },
      { name: 'Explosive Push-ups', sets: '4', reps: '8', rest: '90s', intensity: 80, muscleGroups: ['chest', 'shoulders'], equipment: ['none'] }
    ]
  },
  lb: {
    agility: [
      { name: 'Backpedal + Break', sets: '8', reps: '1 each direction', rest: '60s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Coverage Drill', sets: '6', reps: '15 yards', rest: '75s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Blitz Simulation', sets: '5', reps: '1', rest: '90s', intensity: 90, muscleGroups: ['legs', 'core'], equipment: ['bags'] },
      { name: 'Lateral Shuffle + Sprint', sets: '6', reps: '1', rest: '75s', intensity: 85, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'React and Tackle', sets: '8', reps: '1', rest: '60s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['bags', 'cones'] }
    ],
    strength: [
      { name: 'Squat', sets: '4', reps: '8-10', rest: '2.5 min', intensity: 85, muscleGroups: ['legs', 'glutes'], equipment: ['barbell'] },
      { name: 'Incline Press', sets: '4', reps: '10-12', rest: '2 min', intensity: 75, muscleGroups: ['chest', 'shoulders'], equipment: ['barbell'] },
      { name: 'Romanian Deadlift', sets: '3', reps: '12', rest: '90s', intensity: 75, muscleGroups: ['hamstrings', 'glutes'], equipment: ['barbell'] },
      { name: 'Weighted Dips', sets: '3', reps: '10-12', rest: '90s', intensity: 80, muscleGroups: ['chest', 'triceps'], equipment: ['dip bars', 'weight belt'] },
      { name: 'Plank Variations', sets: '3', reps: '45 seconds', rest: '60s', intensity: 70, muscleGroups: ['core'], equipment: ['none'] }
    ]
  },
  cb: {
    speed: [
      { name: 'Backpedal to Sprint', sets: '8', reps: '1', rest: '90s', intensity: 90, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Mirror + Break', sets: '6', reps: '1 each direction', rest: '75s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['partner'] },
      { name: 'Press Coverage Release', sets: '8', reps: '1', rest: '60s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['bags'] },
      { name: 'Flying 10s', sets: '5', reps: '1', rest: '2.5 min', intensity: 95, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Acceleration Ladder', sets: '4', reps: '2 lengths', rest: '90s', intensity: 80, muscleGroups: ['legs', 'calves'], equipment: ['ladder'] }
    ],
    agility: [
      { name: 'W-Drill', sets: '6', reps: '1', rest: '90s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Hip Turn Drill', sets: '8', reps: '1 each direction', rest: '45s', intensity: 80, muscleGroups: ['legs', 'hips'], equipment: ['cones'] },
      { name: 'Pedal + Plant', sets: '6', reps: '1 each direction', rest: '60s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Ball Reaction Drill', sets: '8', reps: '1', rest: '60s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['tennis balls'] },
      { name: 'Quick Feet Box', sets: '4', reps: '20 seconds', rest: '60s', intensity: 75, muscleGroups: ['legs', 'calves'], equipment: ['box'] }
    ]
  }
};

export function generateWorkout(positionId: string, goalId: string, positionName: string, goalName: string): Workout {
  const position = positions.find(p => p.id === positionId);
  const goal = goals.find(g => g.id === goalId);
  
  if (!position || !goal) {
    throw new Error('Invalid position or goal');
  }

  // Get position-specific exercises
  let exercises: Exercise[] = [];
  
  if (nflWorkoutDatabase[positionId] && nflWorkoutDatabase[positionId][goalId]) {
    exercises = [...nflWorkoutDatabase[positionId][goalId]];
  } else {
    // Fallback to general exercises based on goal and position demands
    exercises = generateFallbackExercises(position, goal);
  }

  // Limit to 5-6 exercises and shuffle for variety
  exercises = shuffleArray(exercises).slice(0, 6);

  // Calculate efficiency with detailed breakdown
  const efficiency = calculateAdvancedEfficiency(position, goal, exercises);
  
  // Determine difficulty based on position and goal
  const difficulty = determineDifficulty(position, goal, exercises);
  
  // Estimate duration
  const estimatedDuration = calculateDuration(exercises);

  return {
    position: positionName,
    goal: goalName,
    exercises,
    efficiency,
    estimatedDuration,
    difficulty
  };
}

function generateFallbackExercises(position: Position, goal: Goal): Exercise[] {
  const fallbackExercises: { [key: string]: Exercise[] } = {
    speed: [
      { name: '40-Yard Dash Repeats', sets: '6', reps: '1', rest: '2-3 min', intensity: 90, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Flying 20s', sets: '5', reps: '1', rest: '3 min', intensity: 95, muscleGroups: ['legs', 'glutes'], equipment: ['cones'] },
      { name: 'Acceleration Ladder', sets: '4', reps: '2 lengths', rest: '90s', intensity: 80, muscleGroups: ['legs', 'calves'], equipment: ['ladder'] },
      { name: 'Resisted Sprints', sets: '6', reps: '20 yards', rest: '2 min', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['resistance bands'] }
    ],
    strength: [
      { name: 'Barbell Back Squat', sets: '4', reps: '6-8', rest: '3 min', intensity: 85, muscleGroups: ['legs', 'glutes', 'core'], equipment: ['barbell'] },
      { name: 'Bench Press', sets: '4', reps: '8-10', rest: '2.5 min', intensity: 80, muscleGroups: ['chest', 'shoulders'], equipment: ['barbell'] },
      { name: 'Deadlift', sets: '3', reps: '5', rest: '3 min', intensity: 90, muscleGroups: ['back', 'legs', 'glutes'], equipment: ['barbell'] },
      { name: 'Pull-ups', sets: '3', reps: '8-12', rest: '2 min', intensity: 75, muscleGroups: ['back', 'biceps'], equipment: ['pull-up bar'] }
    ],
    agility: [
      { name: '5-10-5 Shuttle', sets: '6', reps: '1', rest: '90s', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Three-Cone Drill', sets: '5', reps: '1', rest: '2 min', intensity: 85, muscleGroups: ['legs', 'core'], equipment: ['cones'] },
      { name: 'Lateral Bounds', sets: '4', reps: '8 each way', rest: '60s', intensity: 75, muscleGroups: ['legs', 'glutes'], equipment: ['none'] },
      { name: 'Box Drill', sets: '5', reps: '2', rest: '90s', intensity: 80, muscleGroups: ['legs', 'core'], equipment: ['cones'] }
    ],
    power: [
      { name: 'Box Jumps', sets: '4', reps: '6', rest: '2 min', intensity: 85, muscleGroups: ['legs', 'glutes'], equipment: ['box'] },
      { name: 'Medicine Ball Throws', sets: '4', reps: '8', rest: '90s', intensity: 80, muscleGroups: ['core', 'shoulders'], equipment: ['medicine ball'] },
      { name: 'Power Clean', sets: '4', reps: '5', rest: '2.5 min', intensity: 90, muscleGroups: ['legs', 'back', 'shoulders'], equipment: ['barbell'] }
    ],
    endurance: [
      { name: '300-Yard Shuttle', sets: '3', reps: '1', rest: '3 min', intensity: 85, muscleGroups: ['legs', 'cardiovascular'], equipment: ['cones'] },
      { name: 'Tempo Runs', sets: '4', reps: '100 yards', rest: '90s', intensity: 75, muscleGroups: ['legs', 'cardiovascular'], equipment: ['none'] },
      { name: 'Bike Intervals', sets: '6', reps: '30 seconds', rest: '90s', intensity: 90, muscleGroups: ['legs', 'cardiovascular'], equipment: ['bike'] }
    ],
    flexibility: [
      { name: 'Dynamic Hip Circles', sets: '2', reps: '10 each direction', rest: '30s', intensity: 40, muscleGroups: ['hips'], equipment: ['none'] },
      { name: 'Leg Swings', sets: '2', reps: '15 each leg', rest: '30s', intensity: 40, muscleGroups: ['legs', 'hips'], equipment: ['none'] },
      { name: 'Shoulder Dislocations', sets: '2', reps: '15', rest: '30s', intensity: 40, muscleGroups: ['shoulders'], equipment: ['resistance band'] }
    ]
  };

  return fallbackExercises[goal.category] || fallbackExercises.strength;
}

function calculateAdvancedEfficiency(position: Position, goal: Goal, exercises: Exercise[]): {
  score: number;
  comment: string;
  breakdown: {
    positionRelevance: number;
    intensityBalance: number;
    exerciseVariety: number;
    injuryPrevention: number;
  };
} {
  // Position relevance (40% of score)
  const positionRelevance = calculatePositionRelevance(position, goal, exercises);
  
  // Intensity balance (25% of score)
  const intensityBalance = calculateIntensityBalance(exercises);
  
  // Exercise variety (20% of score)
  const exerciseVariety = calculateExerciseVariety(exercises);
  
  // Injury prevention (15% of score)
  const injuryPrevention = calculateInjuryPrevention(position, exercises);
  
  const totalScore = Math.round(
    positionRelevance * 0.4 +
    intensityBalance * 0.25 +
    exerciseVariety * 0.2 +
    injuryPrevention * 0.15
  );

  const breakdown = {
    positionRelevance: Math.round(positionRelevance),
    intensityBalance: Math.round(intensityBalance),
    exerciseVariety: Math.round(exerciseVariety),
    injuryPrevention: Math.round(injuryPrevention)
  };

  const comment = generateEfficiencyComment(totalScore, breakdown, position, goal);

  return {
    score: Math.min(totalScore, 100),
    comment,
    breakdown
  };
}

function calculatePositionRelevance(position: Position, goal: Goal, exercises: Exercise[]): number {
  const goalDemand = position.physicalDemands[goal.category as keyof typeof position.physicalDemands] || 50;
  const baseScore = goalDemand;
  
  // Bonus for position-specific exercises
  const positionSpecificBonus = exercises.some(ex => 
    ex.name.toLowerCase().includes(position.name.toLowerCase().split(' ')[0])
  ) ? 15 : 0;
  
  return Math.min(baseScore + positionSpecificBonus, 100);
}

function calculateIntensityBalance(exercises: Exercise[]): number {
  const intensities = exercises.map(ex => ex.intensity);
  const avgIntensity = intensities.reduce((a, b) => a + b, 0) / intensities.length;
  
  // Optimal intensity range is 75-85
  if (avgIntensity >= 75 && avgIntensity <= 85) return 95;
  if (avgIntensity >= 70 && avgIntensity <= 90) return 85;
  if (avgIntensity >= 65 && avgIntensity <= 95) return 75;
  return 60;
}

function calculateExerciseVariety(exercises: Exercise[]): number {
  const uniqueMuscleGroups = new Set(exercises.flatMap(ex => ex.muscleGroups)).size;
  const uniqueEquipment = new Set(exercises.flatMap(ex => ex.equipment)).size;
  
  const varietyScore = (uniqueMuscleGroups * 10) + (uniqueEquipment * 5);
  return Math.min(varietyScore, 100);
}

function calculateInjuryPrevention(position: Position, exercises: Exercise[]): number {
  let score = 70; // Base score
  
  // Penalty for high-risk positions without proper warm-up/mobility
  if (position.injuryRisk === 'high') {
    const hasMobility = exercises.some(ex => 
      ex.muscleGroups.includes('core') || ex.name.toLowerCase().includes('mobility')
    );
    if (!hasMobility) score -= 20;
  }
  
  // Bonus for balanced muscle group targeting
  const muscleGroups = exercises.flatMap(ex => ex.muscleGroups);
  const hasCore = muscleGroups.includes('core');
  const hasStabilization = exercises.some(ex => ex.name.toLowerCase().includes('single'));
  
  if (hasCore) score += 10;
  if (hasStabilization) score += 10;
  
  return Math.min(score, 100);
}

function generateEfficiencyComment(score: number, breakdown: any, position: Position, goal: Goal): string {
  if (score >= 90) {
    return `Elite-level workout design perfectly tailored for ${position.name} with exceptional ${goal.name.toLowerCase()} focus. Outstanding position-specific targeting and optimal training balance.`;
  } else if (score >= 80) {
    return `Highly effective routine with strong NFL-level programming for ${position.name}. Excellent ${goal.name.toLowerCase()} development with good position-specific elements.`;
  } else if (score >= 70) {
    return `Solid professional-grade workout for ${position.name} with good ${goal.name.toLowerCase()} targeting. Could benefit from more position-specific exercises or intensity optimization.`;
  } else {
    return `Functional routine covering basic ${goal.name.toLowerCase()} development. Needs refinement for optimal ${position.name}-specific results and NFL-level performance gains.`;
  }
}

function determineDifficulty(position: Position, goal: Goal, exercises: Exercise[]): 'Beginner' | 'Intermediate' | 'Advanced' | 'Elite' {
  const avgIntensity = exercises.reduce((sum, ex) => sum + ex.intensity, 0) / exercises.length;
  const complexityScore = exercises.filter(ex => 
    ex.equipment.length > 1 || ex.name.includes('Single') || ex.name.includes('Explosive')
  ).length;
  
  if (avgIntensity >= 85 && complexityScore >= 3) return 'Elite';
  if (avgIntensity >= 75 && complexityScore >= 2) return 'Advanced';
  if (avgIntensity >= 65) return 'Intermediate';
  return 'Beginner';
}

function calculateDuration(exercises: Exercise[]): number {
  // Estimate based on sets, reps, and rest periods
  let totalMinutes = 0;
  
  exercises.forEach(exercise => {
    const sets = parseInt(exercise.sets) || 3;
    const restSeconds = parseRestTime(exercise.rest);
    const workTime = sets * 45; // Assume 45 seconds per set on average
    const restTime = (sets - 1) * restSeconds;
    totalMinutes += (workTime + restTime) / 60;
  });
  
  return Math.round(totalMinutes + 10); // Add 10 minutes for warm-up/cool-down
}

function parseRestTime(rest: string): number {
  if (rest.includes('min')) {
    return parseInt(rest) * 60;
  }
  return parseInt(rest) || 60;
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}